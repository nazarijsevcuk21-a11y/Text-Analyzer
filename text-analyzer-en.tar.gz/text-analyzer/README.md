# 📊 Text Analyzer - Аналізатор тексту

Потужний інструмент для статистичного аналізу тексту з візуалізацією результатів.

## ✨ Можливості

### 📈 Статистичний аналіз
- Підрахунок слів, речень, символів
- Унікальні слова та багатство словника
- Частота повторень слів
- Розподіл довжини слів
- Середня довжина речень
- Найдовші слова

### 🔍 Текстова обробка
- Токенізація (розбиття на слова)
- Видалення стоп-слів (українська/англійська)
- Очищення від пунктуації
- Розбиття на речення
- Підтримка двох мов

### 📊 Візуалізація
- **Частота слів** - горизонтальна гістограма топ-N слів
- **Розподіл довжини** - розподіл слів по кількості символів
- **Підсумкова дашборд** - 4 графіки з ключовими метриками
- **Візуалізація слів** - bubble chart найчастіших слів
- **Порівняння файлів** - графіки для порівняння текстів

### 💾 Експорт
- CSV - частота слів
- TXT - текстовий звіт з статистикою
- PNG - графіки високої якості (300 DPI)

## 🛠 Технології

- **Python 3.8+**
- **pandas** - обробка даних
- **matplotlib** - створення графіків
- **seaborn** - покращені візуалізації
- **numpy** - числові операції

## 📦 Встановлення

```bash
git clone https://github.com/yourusername/text-analyzer.git
cd text-analyzer
pip install -r requirements.txt
```

## 🚀 Швидкий старт

### Базовий аналіз

```python
from text_analyzer import TextAnalyzer

# Створюємо аналізатор
analyzer = TextAnalyzer(language='uk')

# Завантажуємо текст
text = "Ваш текст для аналізу..."
analyzer.set_text(text)

# Аналізуємо
analyzer.tokenize()
analyzer.split_sentences()

# Отримуємо статистику
stats = analyzer.get_basic_stats()
print(stats)
```

### Візуалізація

```python
# Графік частоти слів
analyzer.plot_word_frequency(top_n=20)

# Розподіл довжини слів
analyzer.plot_word_length_distribution()

# Підсумковий звіт
analyzer.plot_statistics_summary()
```

### Аналіз файлу

```python
analyzer = TextAnalyzer(language='uk')
analyzer.load_text('article.txt')
analyzer.tokenize()

# Генеруємо звіт
print(analyzer.generate_report())
analyzer.save_report('report.txt')
```

## 📚 API Reference

### TextAnalyzer

#### `__init__(language='uk')`
Ініціалізація аналізатора. Мова: 'uk' або 'en'.

#### `load_text(filepath)`
Завантажує текст з файлу.

#### `set_text(text)`
Встановлює текст для аналізу.

#### `tokenize(clean=True)`
Розбиває на слова. clean=True видаляє пунктуацію.

#### `split_sentences()`
Розбиває на речення.

#### `get_basic_stats()`
Повертає словник з основною статистикою:
- total_characters
- total_words
- unique_words
- total_sentences
- avg_word_length
- avg_sentence_length
- vocabulary_richness

#### `word_frequency(top_n=20, remove_stop_words=True)`
Повертає Counter з частотою слів.

#### `plot_word_frequency(top_n=20, remove_stop_words=True, save=True)`
Створює графік частоти слів.

#### `plot_word_length_distribution(save=True)`
Графік розподілу слів по довжині.

#### `plot_statistics_summary(save=True)`
Підсумковий графік з 4 панелями.

#### `generate_report()`
Генерує текстовий звіт.

#### `export_to_csv(frequency, filename)`
Експортує частоту слів в CSV.

## 📝 Приклади

### Порівняння текстів

```python
from text_analyzer import analyze_multiple_files

files = ['text1.txt', 'text2.txt', 'text3.txt']
df = analyze_multiple_files(files, language='uk')

print(df)
# Автоматично створюється графік порівняння
```

### Аналіз англійського тексту

```python
analyzer = TextAnalyzer(language='en')
analyzer.set_text("Your English text here...")
analyzer.tokenize()

# Англійські стоп-слова видаляються автоматично
freq = analyzer.word_frequency(top_n=15, remove_stop_words=True)
```

### Власні стоп-слова

```python
analyzer = TextAnalyzer()
analyzer.stop_words = {'слово1', 'слово2', 'слово3'}

analyzer.set_text(text)
freq = analyzer.word_frequency(remove_stop_words=True)
```

## 📊 Формат звіту

```
============================================================
                    ЗВІТ АНАЛІЗУ ТЕКСТУ
============================================================

📊 ОСНОВНА СТАТИСТИКА
------------------------------------------------------------
Всього символів:          1,234
Всього слів:              200
Унікальних слів:          150
Речень:                   15

Середня довжина слова:    5.5 символів
Середня довжина речення:  13.3 слів

Багатство словника:       75.0%

============================================================

🔝 ТОП-10 НАЙЧАСТІШИХ СЛІВ
------------------------------------------------------------
 1. python              -   12 разів
 2. аналіз              -    8 разів
 ...
```

## 🎨 Типи графіків

### 1. Word Frequency (word_frequency.png)
Горизонтальна гістограма з топ-N найчастіших слів.

### 2. Word Length Distribution (word_length_distribution.png)
Розподіл кількості слів по їх довжині.

### 3. Statistics Summary (statistics_summary.png)
4 графіки:
- Основні показники (слова, унікальні, речення)
- Середні значення (довжина слова, слів у реченні)
- Співвідношення (унікальні vs повторювані)
- Текстова інформація

### 4. Word Visualization (word_visualization.png)
Bubble chart з найчастішими словами.

### 5. Comparison (comparison.png)
Порівняння декількох файлів по 4 метриках.

## 📁 Структура

```
text-analyzer/
├── text_analyzer.py      # Основний модуль
├── examples.py           # 7 прикладів
├── requirements.txt      # Залежності
├── README.md            # Документація
└── output/              # Вихідні файли
    ├── *.png            # Графіки
    ├── *.csv            # Дані
    └── *.txt            # Звіти
```

## 🎯 Use Cases

### 1. Аналіз статей
Аналізуйте новинні статті, блог-пости, наукові роботи.

### 2. Порівняння авторів
Порівнюйте стиль написання різних авторів.

### 3. SEO аналіз
Аналізуйте частоту ключових слів у контенті.

### 4. Освіта
Перевіряйте складність текстів для різних рівнів.

### 5. Дослідження
Статистичний аналіз корпусів текстів.

## 🔧 Налаштування

### Matplotlib стилі

```python
import matplotlib.pyplot as plt
plt.style.use('seaborn')
```

### Розмір графіків

```python
plt.rcParams['figure.figsize'] = (16, 10)
```

### DPI для експорту

```python
plt.savefig('graph.png', dpi=300)  # Висока якість
```

## 📈 Метрики

### Vocabulary Richness (Багатство словника)
```
(Унікальні слова / Всього слів) * 100%
```

Чим вище, тим різноманітніший словник.

### Average Word Length
```
Сума довжин всіх слів / Кількість слів
```

Показує складність лексики.

### Average Sentence Length
```
Кількість слів / Кількість речень
```

Показує складність синтаксису.

## 🤝 Внесок

1. Fork
2. Create branch: `git checkout -b feature/NewFeature`
3. Commit: `git commit -m 'Add NewFeature'`
4. Push: `git push origin feature/NewFeature`
5. Pull Request

## 📄 Ліцензія

MIT License

## 👤 Автор

[@your_username](https://github.com/your_username)

---

⭐️ Поставте зірочку якщо проект корисний!
