"""
Приклади використання Text Analyzer
"""

from text_analyzer import TextAnalyzer, analyze_multiple_files
import logging

logging.basicConfig(level=logging.INFO)


def example_1_basic_analysis():
    """Приклад 1: Базовий аналіз тексту"""
    print("\n=== Приклад 1: Базовий аналіз ===")
    
    text = """
    Python - це потужна та універсальна мова програмування. 
    Python використовується для веб-розробки, аналізу даних, 
    машинного навчання та автоматизації. Python має чудову 
    документацію та велику спільноту розробників.
    """
    
    analyzer = TextAnalyzer(language='uk')
    analyzer.set_text(text)
    analyzer.tokenize()
    
    stats = analyzer.get_basic_stats()
    print("\nСтатистика:")
    for key, value in stats.items():
        print(f"  {key}: {value}")


def example_2_word_frequency():
    """Приклад 2: Частота слів"""
    print("\n=== Приклад 2: Аналіз частоти слів ===")
    
    text = """
    Машинне навчання - це підрозділ штучного інтелекту. 
    Машинне навчання дозволяє комп'ютерам вчитися на даних.
    Глибинне навчання - це підрозділ машинного навчання.
    Нейронні мережі використовуються в глибинному навчанні.
    """
    
    analyzer = TextAnalyzer(language='uk')
    analyzer.set_text(text)
    analyzer.tokenize()
    
    # Частота без стоп-слів
    freq = analyzer.word_frequency(top_n=10, remove_stop_words=True)
    
    print("\nТоп-10 слів:")
    for word, count in freq.most_common(10):
        print(f"  {word}: {count} разів")
    
    # Графік
    analyzer.plot_word_frequency(top_n=10)


def example_3_text_from_file():
    """Приклад 3: Аналіз файлу"""
    print("\n=== Приклад 3: Аналіз текстового файлу ===")
    
    # Створюємо тестовий файл
    with open('sample.txt', 'w', encoding='utf-8') as f:
        f.write("""
        Аналіз тексту - це важлива задача обробки природної мови.
        Текстовий аналіз допомагає зрозуміти структуру та зміст документів.
        Статистичний аналіз тексту включає підрахунок слів та частоти.
        Візуалізація результатів аналізу робить дані зрозумілішими.
        Python пропонує потужні інструменти для аналізу тексту.
        """)
    
    analyzer = TextAnalyzer(language='uk')
    analyzer.load_text('sample.txt')
    analyzer.tokenize()
    analyzer.split_sentences()
    
    # Генеруємо повний звіт
    print(analyzer.generate_report())
    analyzer.save_report('example3_report.txt')


def example_4_visualization():
    """Приклад 4: Створення всіх візуалізацій"""
    print("\n=== Приклад 4: Повний набір візуалізацій ===")
    
    text = """
    Візуалізація даних є критично важливою для аналізу інформації.
    Графіки та діаграми допомагають побачити патерни в даних.
    Matplotlib та Seaborn - популярні бібліотеки для візуалізації.
    Гістограми показують розподіл даних. Кругові діаграми відображають 
    пропорції. Лінійні графіки демонструють тренди в часі.
    Boxplot допомагає виявити викиди. Heatmap показує кореляції.
    Scatter plot відображає зв'язки між змінними.
    """
    
    analyzer = TextAnalyzer(language='uk')
    analyzer.set_text(text)
    analyzer.tokenize()
    analyzer.split_sentences()
    
    # Всі типи візуалізацій
    print("Створення графіків...")
    analyzer.plot_word_frequency(top_n=15)
    analyzer.plot_word_length_distribution()
    analyzer.plot_statistics_summary()
    analyzer.plot_word_cloud_data(top_n=20)
    
    print("✅ Всі графіки створено в папці output/")


def example_5_english_text():
    """Приклад 5: Аналіз англійського тексту"""
    print("\n=== Приклад 5: Англійський текст ===")
    
    text = """
    Data science is an interdisciplinary field. Data science combines 
    statistics, programming, and domain knowledge. Python and R are 
    popular languages for data science. Machine learning is a key 
    component of data science. Visualization helps communicate insights.
    """
    
    # Англійська мова
    analyzer = TextAnalyzer(language='en')
    analyzer.set_text(text)
    analyzer.tokenize()
    
    stats = analyzer.get_basic_stats()
    print("\nStatistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Частота англійських слів
    freq = analyzer.word_frequency(top_n=10, remove_stop_words=True)
    print("\nTop words:")
    for word, count in freq.most_common(10):
        print(f"  {word}: {count}")


def example_6_compare_texts():
    """Приклад 6: Порівняння текстів"""
    print("\n=== Приклад 6: Порівняння текстів ===")
    
    # Створюємо тестові файли
    texts = {
        'text1.txt': "Короткий текст. Всього кілька речень. Прості слова.",
        'text2.txt': """
            Довший та складніший текст з багатьма різноманітними словами.
            Використовуються складніші конструкції речень та термінологія.
            Аналіз демонструє відмінності у складності текстів.
        """,
        'text3.txt': """
            Технічний текст про програмування та алгоритми.
            Містить специфічну термінологію та професійну лексику.
            Демонструє високу щільність унікальних термінів.
        """
    }
    
    # Створюємо файли
    for filename, content in texts.items():
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
    
    # Порівнюємо
    df = analyze_multiple_files(list(texts.keys()), language='uk')
    
    print("\nПорівняльна таблиця:")
    print(df[['filename', 'total_words', 'unique_words', 'vocabulary_richness']])
    
    print("\n✅ Графік порівняння створено: output/comparison.png")


def example_7_export_data():
    """Приклад 7: Експорт даних"""
    print("\n=== Приклад 7: Експорт даних ===")
    
    text = """
    Експорт даних дозволяє зберігати результати аналізу.
    CSV формат зручний для подальшої обробки в Excel.
    JSON формат корисний для веб-додатків та API.
    Текстові звіти зручні для читання людиною.
    """
    
    analyzer = TextAnalyzer(language='uk')
    analyzer.set_text(text)
    analyzer.tokenize()
    
    # Експорт частоти слів
    freq = analyzer.word_frequency(top_n=20, remove_stop_words=True)
    analyzer.export_to_csv(freq, 'example7_frequency.csv')
    
    # Текстовий звіт
    analyzer.save_report('example7_report.txt')
    
    print("✅ Дані експортовано:")
    print("  - example7_frequency.csv")
    print("  - example7_report.txt")


def run_all_examples():
    """Запуск всіх прикладів"""
    examples = [
        example_1_basic_analysis,
        example_2_word_frequency,
        example_3_text_from_file,
        example_4_visualization,
        example_5_english_text,
        example_6_compare_texts,
        example_7_export_data
    ]
    
    for example in examples:
        try:
            example()
            print("\n" + "="*60)
        except Exception as e:
            print(f"Помилка в {example.__name__}: {e}")


if __name__ == "__main__":
    run_all_examples()
