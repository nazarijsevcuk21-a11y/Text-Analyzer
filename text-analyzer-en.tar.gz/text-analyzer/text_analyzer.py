"""
Text Analyzer - Інструмент для аналізу тексту
Підрахунок слів, частота, стоп-слова, візуалізація
"""

import re
import string
from collections import Counter
from pathlib import Path
from typing import List, Dict, Tuple
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import logging
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Встановлюємо стиль для графіків
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 10


class TextAnalyzer:
    """Клас для аналізу текстових даних"""
    
    # Стоп-слова для української мови
    STOP_WORDS_UK = {
        'і', 'в', 'у', 'на', 'з', 'по', 'до', 'за', 'від', 'під', 'над', 'про',
        'це', 'той', 'та', 'як', 'що', 'він', 'вона', 'воно', 'вони',
        'я', 'ти', 'ми', 'ви', 'його', 'її', 'їх', 'мій', 'твій', 'наш', 'ваш',
        'був', 'була', 'було', 'були', 'є', 'бути', 'буде', 'будуть',
        'не', 'ні', 'так', 'але', 'а', 'або', 'чи', 'якщо', 'тому', 'коли'
    }
    
    # Стоп-слова для англійської мови
    STOP_WORDS_EN = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
        'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
        'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these',
        'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'my', 'your',
        'his', 'her', 'its', 'our', 'their', 'not', 'no', 'yes'
    }
    
    def __init__(self, language: str = 'uk'):
        self.language = language
        self.stop_words = self.STOP_WORDS_UK if language == 'uk' else self.STOP_WORDS_EN
        self.text = ""
        self.words = []
        self.sentences = []
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)
    
    def load_text(self, filepath: str) -> str:
        """Завантажує текст з файлу"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                self.text = f.read()
            logger.info(f"Завантажено файл: {filepath} ({len(self.text)} символів)")
            return self.text
        except Exception as e:
            logger.error(f"Помилка читання файлу: {e}")
            return ""
    
    def set_text(self, text: str):
        """Встановлює текст для аналізу"""
        self.text = text
        logger.info(f"Текст встановлено ({len(text)} символів)")
    
    def clean_text(self, remove_punctuation: bool = True, 
                   remove_digits: bool = False) -> str:
        """Очищає текст"""
        text = self.text.lower()
        
        if remove_punctuation:
            text = text.translate(str.maketrans('', '', string.punctuation))
        
        if remove_digits:
            text = re.sub(r'\d+', '', text)
        
        # Видаляємо зайві пробіли
        text = ' '.join(text.split())
        
        return text
    
    def tokenize(self, clean: bool = True) -> List[str]:
        """Розбиває текст на слова"""
        if clean:
            text = self.clean_text()
        else:
            text = self.text
        
        # Розбиваємо на слова
        self.words = [word for word in text.split() if word]
        logger.info(f"Знайдено {len(self.words)} слів")
        return self.words
    
    def split_sentences(self) -> List[str]:
        """Розбиває текст на речення"""
        # Простий спліт по крапці, знаку оклику, питання
        self.sentences = re.split(r'[.!?]+', self.text)
        self.sentences = [s.strip() for s in self.sentences if s.strip()]
        logger.info(f"Знайдено {len(self.sentences)} речень")
        return self.sentences
    
    def count_words(self) -> int:
        """Підраховує загальну кількість слів"""
        if not self.words:
            self.tokenize()
        return len(self.words)
    
    def count_unique_words(self) -> int:
        """Підраховує унікальні слова"""
        if not self.words:
            self.tokenize()
        return len(set(self.words))
    
    def word_frequency(self, top_n: int = 20, 
                      remove_stop_words: bool = True) -> Counter:
        """Підраховує частоту слів"""
        if not self.words:
            self.tokenize()
        
        words = self.words
        if remove_stop_words:
            words = [w for w in words if w not in self.stop_words]
        
        frequency = Counter(words)
        logger.info(f"Топ-{top_n} слів розраховано")
        return frequency
    
    def get_basic_stats(self) -> Dict:
        """Базова статистика тексту"""
        if not self.words:
            self.tokenize()
        if not self.sentences:
            self.split_sentences()
        
        total_words = len(self.words)
        unique_words = len(set(self.words))
        total_chars = len(self.text)
        total_sentences = len(self.sentences)
        
        avg_word_length = sum(len(w) for w in self.words) / total_words if total_words else 0
        avg_sentence_length = total_words / total_sentences if total_sentences else 0
        
        stats = {
            'total_characters': total_chars,
            'total_words': total_words,
            'unique_words': unique_words,
            'total_sentences': total_sentences,
            'avg_word_length': round(avg_word_length, 2),
            'avg_sentence_length': round(avg_sentence_length, 2),
            'vocabulary_richness': round(unique_words / total_words * 100, 2) if total_words else 0
        }
        
        return stats
    
    def find_longest_words(self, n: int = 10) -> List[Tuple[str, int]]:
        """Знаходить найдовші слова"""
        if not self.words:
            self.tokenize()
        
        word_lengths = [(word, len(word)) for word in set(self.words)]
        word_lengths.sort(key=lambda x: x[1], reverse=True)
        
        return word_lengths[:n]
    
    def get_word_length_distribution(self) -> Counter:
        """Розподіл слів по довжині"""
        if not self.words:
            self.tokenize()
        
        lengths = [len(word) for word in self.words]
        return Counter(lengths)
    
    def export_to_csv(self, frequency: Counter, filename: str = "word_frequency.csv"):
        """Експортує частоту слів в CSV"""
        filepath = self.output_dir / filename
        
        df = pd.DataFrame(frequency.most_common(), columns=['Word', 'Frequency'])
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        
        logger.info(f"✅ Експортовано в {filepath}")
        return filepath
    
    def plot_word_frequency(self, top_n: int = 20, 
                           remove_stop_words: bool = True,
                           save: bool = True):
        """Візуалізація частоти слів"""
        frequency = self.word_frequency(top_n, remove_stop_words)
        
        # Отримуємо топ N слів
        words, counts = zip(*frequency.most_common(top_n))
        
        # Створюємо графік
        plt.figure(figsize=(14, 8))
        colors = plt.cm.viridis(range(len(words)))
        
        plt.barh(range(len(words)), counts, color=colors)
        plt.yticks(range(len(words)), words)
        plt.xlabel('Частота', fontsize=12)
        plt.ylabel('Слова', fontsize=12)
        plt.title(f'Топ-{top_n} найчастіших слів', fontsize=14, fontweight='bold')
        plt.gca().invert_yaxis()
        
        # Додаємо значення на графік
        for i, count in enumerate(counts):
            plt.text(count, i, f' {count}', va='center', fontsize=10)
        
        plt.tight_layout()
        
        if save:
            filepath = self.output_dir / "word_frequency.png"
            plt.savefig(filepath, dpi=300, bbox_inches='tight')
            logger.info(f"✅ Графік збережено: {filepath}")
            plt.close()
        else:
            plt.show()
    
    def plot_word_cloud_data(self, top_n: int = 50, save: bool = True):
        """Створює дані для word cloud (альтернатива)"""
        frequency = self.word_frequency(top_n, remove_stop_words=True)
        
        plt.figure(figsize=(16, 10))
        
        words = []
        sizes = []
        for word, count in frequency.most_common(top_n):
            words.append(word)
            sizes.append(count)
        
        # Bubble chart
        colors = plt.cm.Set3(range(len(words)))
        
        # Розміщуємо слова по спіралі
        import math
        positions = []
        for i in range(len(words)):
            angle = i * 0.5
            radius = 0.5 + i * 0.1
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            positions.append((x, y))
        
        for i, (word, size) in enumerate(zip(words, sizes)):
            x, y = positions[i]
            plt.scatter(x, y, s=size*100, c=[colors[i]], alpha=0.6)
            plt.text(x, y, word, ha='center', va='center', fontsize=8+size/2)
        
        plt.axis('equal')
        plt.axis('off')
        plt.title('Візуалізація частоти слів', fontsize=16, fontweight='bold')
        
        if save:
            filepath = self.output_dir / "word_visualization.png"
            plt.savefig(filepath, dpi=300, bbox_inches='tight')
            logger.info(f"✅ Візуалізацію збережено: {filepath}")
            plt.close()
        else:
            plt.show()
    
    def plot_word_length_distribution(self, save: bool = True):
        """Графік розподілу довжини слів"""
        length_dist = self.get_word_length_distribution()
        
        lengths = sorted(length_dist.keys())
        counts = [length_dist[l] for l in lengths]
        
        plt.figure(figsize=(12, 6))
        plt.bar(lengths, counts, color='skyblue', edgecolor='navy', alpha=0.7)
        plt.xlabel('Довжина слова (символів)', fontsize=12)
        plt.ylabel('Кількість слів', fontsize=12)
        plt.title('Розподіл слів по довжині', fontsize=14, fontweight='bold')
        plt.grid(axis='y', alpha=0.3)
        
        # Додаємо середню лінію
        avg_length = sum(l * c for l, c in length_dist.items()) / sum(length_dist.values())
        plt.axvline(avg_length, color='red', linestyle='--', 
                   label=f'Середня довжина: {avg_length:.1f}')
        plt.legend()
        
        plt.tight_layout()
        
        if save:
            filepath = self.output_dir / "word_length_distribution.png"
            plt.savefig(filepath, dpi=300, bbox_inches='tight')
            logger.info(f"✅ Графік збережено: {filepath}")
            plt.close()
        else:
            plt.show()
    
    def plot_statistics_summary(self, save: bool = True):
        """Підсумковий графік статистики"""
        stats = self.get_basic_stats()
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle('Підсумкова статистика тексту', fontsize=16, fontweight='bold')
        
        # 1. Основні показники
        ax1 = axes[0, 0]
        metrics = ['Всього\nслів', 'Унікальних\nслів', 'Речень']
        values = [stats['total_words'], stats['unique_words'], stats['total_sentences']]
        colors = ['#3498db', '#2ecc71', '#e74c3c']
        
        bars = ax1.bar(metrics, values, color=colors, alpha=0.7)
        ax1.set_ylabel('Кількість', fontsize=11)
        ax1.set_title('Основні показники', fontsize=12, fontweight='bold')
        
        for bar, value in zip(bars, values):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(value)}', ha='center', va='bottom', fontsize=10)
        
        # 2. Середні значення
        ax2 = axes[0, 1]
        avg_metrics = ['Довжина\nслова', 'Слів у\nреченні']
        avg_values = [stats['avg_word_length'], stats['avg_sentence_length']]
        colors2 = ['#9b59b6', '#f39c12']
        
        bars = ax2.bar(avg_metrics, avg_values, color=colors2, alpha=0.7)
        ax2.set_ylabel('Середнє значення', fontsize=11)
        ax2.set_title('Середні показники', fontsize=12, fontweight='bold')
        
        for bar, value in zip(bars, avg_values):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'{value:.1f}', ha='center', va='bottom', fontsize=10)
        
        # 3. Співвідношення
        ax3 = axes[1, 0]
        labels = ['Унікальні\nслова', 'Повторювані\nслова']
        sizes = [stats['unique_words'], stats['total_words'] - stats['unique_words']]
        colors3 = ['#1abc9c', '#95a5a6']
        explode = (0.1, 0)
        
        ax3.pie(sizes, explode=explode, labels=labels, colors=colors3,
               autopct='%1.1f%%', startangle=90, textprops={'fontsize': 10})
        ax3.set_title('Співвідношення слів', fontsize=12, fontweight='bold')
        
        # 4. Текстова інформація
        ax4 = axes[1, 1]
        ax4.axis('off')
        
        info_text = f"""
        📊 ДЕТАЛЬНА СТАТИСТИКА
        
        Всього символів: {stats['total_characters']:,}
        Всього слів: {stats['total_words']:,}
        Унікальних слів: {stats['unique_words']:,}
        Речень: {stats['total_sentences']:,}
        
        Середня довжина слова: {stats['avg_word_length']:.2f}
        Середня довжина речення: {stats['avg_sentence_length']:.2f}
        
        Багатство словника: {stats['vocabulary_richness']:.1f}%
        
        Дата аналізу: {datetime.now().strftime("%Y-%m-%d %H:%M")}
        """
        
        ax4.text(0.1, 0.5, info_text, fontsize=11, family='monospace',
                verticalalignment='center')
        
        plt.tight_layout()
        
        if save:
            filepath = self.output_dir / "statistics_summary.png"
            plt.savefig(filepath, dpi=300, bbox_inches='tight')
            logger.info(f"✅ Підсумковий графік збережено: {filepath}")
            plt.close()
        else:
            plt.show()
    
    def generate_report(self) -> str:
        """Генерує текстовий звіт"""
        if not self.words:
            self.tokenize()
        if not self.sentences:
            self.split_sentences()
        
        stats = self.get_basic_stats()
        frequency = self.word_frequency(top_n=10, remove_stop_words=True)
        longest_words = self.find_longest_words(5)
        
        report = f"""
{'='*60}
                    ЗВІТ АНАЛІЗУ ТЕКСТУ
{'='*60}

📊 ОСНОВНА СТАТИСТИКА
{'-'*60}
Всього символів:          {stats['total_characters']:,}
Всього слів:              {stats['total_words']:,}
Унікальних слів:          {stats['unique_words']:,}
Речень:                   {stats['total_sentences']:,}

Середня довжина слова:    {stats['avg_word_length']:.2f} символів
Середня довжина речення:  {stats['avg_sentence_length']:.2f} слів

Багатство словника:       {stats['vocabulary_richness']:.1f}%

{'='*60}

🔝 ТОП-10 НАЙЧАСТІШИХ СЛІВ
{'-'*60}
"""
        
        for i, (word, count) in enumerate(frequency.most_common(10), 1):
            report += f"{i:2d}. {word:20s} - {count:4d} разів\n"
        
        report += f"\n{'='*60}\n\n"
        report += "📏 НАЙДОВШІ СЛОВА\n"
        report += f"{'-'*60}\n"
        
        for i, (word, length) in enumerate(longest_words, 1):
            report += f"{i}. {word} ({length} символів)\n"
        
        report += f"\n{'='*60}\n"
        report += f"Дата створення звіту: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"{'='*60}\n"
        
        return report
    
    def save_report(self, filename: str = "text_analysis_report.txt") -> Path:
        """Зберігає звіт у файл"""
        report = self.generate_report()
        filepath = self.output_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        
        logger.info(f"✅ Звіт збережено: {filepath}")
        return filepath


def analyze_multiple_files(filepaths: List[str], language: str = 'uk'):
    """Аналізує декілька файлів та порівнює"""
    results = []
    
    for filepath in filepaths:
        analyzer = TextAnalyzer(language=language)
        analyzer.load_text(filepath)
        analyzer.tokenize()
        analyzer.split_sentences()
        
        stats = analyzer.get_basic_stats()
        stats['filename'] = Path(filepath).name
        results.append(stats)
    
    # Створюємо DataFrame для порівняння
    df = pd.DataFrame(results)
    
    # Експорт
    output_path = Path("output/comparison.csv")
    df.to_csv(output_path, index=False, encoding='utf-8-sig')
    logger.info(f"✅ Порівняння збережено: {output_path}")
    
    # Візуалізація порівняння
    plot_comparison(df)
    
    return df


def plot_comparison(df: pd.DataFrame):
    """Візуалізація порівняння декількох файлів"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Порівняння текстових файлів', fontsize=16, fontweight='bold')
    
    # 1. Кількість слів
    ax1 = axes[0, 0]
    ax1.bar(df['filename'], df['total_words'], color='skyblue')
    ax1.set_ylabel('Кількість слів')
    ax1.set_title('Загальна кількість слів')
    ax1.tick_params(axis='x', rotation=45)
    
    # 2. Унікальні слова
    ax2 = axes[0, 1]
    ax2.bar(df['filename'], df['unique_words'], color='lightgreen')
    ax2.set_ylabel('Унікальні слова')
    ax2.set_title('Кількість унікальних слів')
    ax2.tick_params(axis='x', rotation=45)
    
    # 3. Багатство словника
    ax3 = axes[1, 0]
    ax3.bar(df['filename'], df['vocabulary_richness'], color='coral')
    ax3.set_ylabel('Відсоток (%)')
    ax3.set_title('Багатство словника')
    ax3.tick_params(axis='x', rotation=45)
    
    # 4. Середня довжина речення
    ax4 = axes[1, 1]
    ax4.bar(df['filename'], df['avg_sentence_length'], color='plum')
    ax4.set_ylabel('Слів у реченні')
    ax4.set_title('Середня довжина речення')
    ax4.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    filepath = Path("output/comparison.png")
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    logger.info(f"✅ Графік порівняння збережено: {filepath}")
    plt.close()


def main():
    """Головна функція - демонстрація роботи"""
    logger.info("=== Text Analyzer - Демонстрація ===")
    
    # Приклад тексту
    sample_text = """
    Штучний інтелект змінює наш світ. Машинне навчання та глибинне навчання 
    стають все більш потужними. Нейронні мережі здатні розпізнавати образи, 
    розуміти природну мову та приймати рішення. Python є найпопулярнішою мовою 
    для розробки AI. Бібліотеки як TensorFlow, PyTorch та scikit-learn роблять 
    машинне навчання доступним для всіх. Дані - це нова нафта. Великі дані та 
    аналітика відіграють ключову роль у сучасному бізнесі. Візуалізація даних 
    допомагає приймати кращі рішення. Автоматизація та оптимізація процесів 
    стають нормою. Майбутнє за технологіями.
    """
    
    # Створюємо аналізатор
    analyzer = TextAnalyzer(language='uk')
    analyzer.set_text(sample_text)
    
    # Аналізуємо
    logger.info("\n📊 Аналіз тексту...")
    analyzer.tokenize()
    analyzer.split_sentences()
    
    # Виводимо статистику
    stats = analyzer.get_basic_stats()
    print(f"\n📈 Статистика:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Генеруємо звіт
    logger.info("\n📄 Генерація звіту...")
    print(analyzer.generate_report())
    analyzer.save_report()
    
    # Створюємо візуалізації
    logger.info("\n📊 Створення візуалізацій...")
    analyzer.plot_word_frequency(top_n=15)
    analyzer.plot_word_length_distribution()
    analyzer.plot_statistics_summary()
    analyzer.plot_word_cloud_data(top_n=30)
    
    # Експорт даних
    logger.info("\n💾 Експорт даних...")
    frequency = analyzer.word_frequency(top_n=50, remove_stop_words=True)
    analyzer.export_to_csv(frequency)
    
    logger.info("\n✅ Аналіз завершено! Перевірте папку 'output'")


if __name__ == "__main__":
    main()
