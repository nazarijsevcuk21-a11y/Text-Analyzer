# 🚀 Швидкий старт - Text Analyzer

## За 2 хвилини до першого аналізу!

### Крок 1: Встановлення

```bash
pip install -r requirements.txt
```

### Крок 2: Запуск

```bash
python text_analyzer.py
```

Готово! Аналізатор:
- Проаналізував приклад тексту
- Створив 4 типи графіків
- Згенерував текстовий звіт
- Експортував дані в CSV

Перевірте папку `output/`!

---

## 💡 Швидкі приклади

### Аналіз свого тексту

```python
from text_analyzer import TextAnalyzer

analyzer = TextAnalyzer(language='uk')
analyzer.set_text("Ваш текст тут...")
analyzer.tokenize()

# Статистика
stats = analyzer.get_basic_stats()
print(stats)

# Графіки
analyzer.plot_word_frequency()
analyzer.plot_statistics_summary()
```

### Аналіз файлу

```python
analyzer = TextAnalyzer()
analyzer.load_text('article.txt')
analyzer.tokenize()
analyzer.save_report()
```

### Частота слів

```python
analyzer.tokenize()
freq = analyzer.word_frequency(top_n=20, remove_stop_words=True)

for word, count in freq.most_common(10):
    print(f"{word}: {count}")
```

---

## 🎯 Запуск прикладів

```bash
python examples.py
```

Побачите 7 різних сценаріїв!

---

**Готово!** Тепер у вас є працюючий аналізатор тексту 🎉
